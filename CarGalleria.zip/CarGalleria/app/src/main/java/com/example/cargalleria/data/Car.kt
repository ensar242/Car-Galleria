package com.example.cargalleria.data

data class Car(val name :String ,
               val imageUri: String,val year:Int,val hp:Int,val km:Int,val price:Int
)
