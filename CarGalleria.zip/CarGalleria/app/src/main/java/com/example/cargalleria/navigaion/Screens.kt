package com.example.cargalleria.navigaion

enum class Screens {
        HomeScreen,
        AddCarScreen,
        FavoritesScreen,
        SettingScreen

}